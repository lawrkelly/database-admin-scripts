Features list for option: --feature (dev only)
---


* cve_recommendations
* log_file_recommendations
* make_recommendations
* mariadb_aria
* mariadb_connect
* mariadb_galera
* mariadb_rockdb
* mariadb_spider
* mariadb_threadpool
* mariadb_tokudb
* mariadb_xtradb
* mysql_databases
* mysql_indexes
* mysql_innodb
* mysql_myisam
* mysql_pfs
* mysql_routines
* mysql_setup
* mysql_stats
* mysql_table_structures
* mysql_tables
* mysql_triggers
* mysql_views
* security_recommendations
* system_recommendations
* validate_mysql_version
* validate_tuner_version
